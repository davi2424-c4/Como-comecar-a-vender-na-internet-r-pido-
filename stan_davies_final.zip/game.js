
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

ctx.fillStyle = "white";
ctx.font = "20px monospace";
ctx.fillText("Stan Davies - Fase 1", 300, 100);
ctx.fillText("Velocímetro carregando...", 270, 200);
ctx.fillText("Menu, loja e lógica completa vem aqui!", 220, 300);
