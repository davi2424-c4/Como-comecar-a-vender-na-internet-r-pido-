
let canvas, ctx;
let assets = {};
let gameState = "velocity";
let force = 0, curve = 0, height = 0, stage = 1, coins = 0;
let velocityBars = ["force", "curve", "height"];
let currentBar = 0, barValue = 0, barDirection = 1, barSpeed = 2;
let ballX = 0, ballY = 0, ballMoving = false;

function loadAssets(callback) {
  const images = ["background", "player", "goalkeeper", "barrier", "ball"];
  let loaded = 0;
  for (let img of images) {
    assets[img] = new Image();
    assets[img].src = "assets/" + img + ".png";
    assets[img].onload = () => {
      loaded++;
      if (loaded === images.length) callback();
    };
  }
}

function startGame() {
  document.getElementById("title-screen").style.display = "none";
  document.getElementById("gameCanvas").style.display = "block";
  canvas = document.getElementById("gameCanvas");
  ctx = canvas.getContext("2d");
  loadAssets(() => {
    canvas.addEventListener("click", onCanvasClick);
    setInterval(update, 30);
  });
}

function showTutorial() {
  alert("Tutorial: Clique para travar os 3 velocímetros (força, curva e altura). Mire para fazer o gol!");
}

function showStore() {
  alert("Loja (em breve): Compre habilidades como chute perfeito e congelar goleiro.");
}

function showCodeMenu() {
  const code = prompt("Digite o código:");
  if (code === "CHATEDAVIES") {
    coins = 999999;
    alert("Código ativado! Dinheiro ilimitado!");
  } else {
    alert("Código inválido.");
  }
}

function onCanvasClick() {
  if (gameState === "velocity") {
    if (velocityBars[currentBar] === "force") force = barValue;
    if (velocityBars[currentBar] === "curve") curve = barValue;
    if (velocityBars[currentBar] === "height") height = barValue;
    currentBar++;
    if (currentBar >= velocityBars.length) {
      gameState = "shot";
      ballX = 390;
      ballY = 500;
      ballMoving = true;
    }
  }
}

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(assets["background"], 0, 0);

  // Draw characters
  ctx.drawImage(assets["player"], 390, 520);
  ctx.drawImage(assets["goalkeeper"], 390 + (Math.sin(stage) * 50), 100);
  ctx.drawImage(assets["barrier"], 390, 300);

  if (gameState === "velocity") {
    drawBar(velocityBars[currentBar]);
  } else if (gameState === "shot") {
    simulateShot();
  }
}

function drawBar(label) {
  ctx.fillStyle = "#0f0";
  ctx.fillText("Clique para travar o valor de: " + label, 300, 50);
  barValue += barDirection * barSpeed;
  if (barValue > 100 || barValue < 0) barDirection *= -1;
  ctx.fillRect(200, 100, barValue * 4, 30);
  ctx.strokeStyle = "#fff";
  ctx.strokeRect(200, 100, 400, 30);
}

function simulateShot() {
  if (!ballMoving) return;
  ballY -= force / 5;
  ballX += (curve - 50) / 20;
  ctx.drawImage(assets["ball"], ballX, ballY);

  if (ballY < 120) {
    ballMoving = false;
    let goalSuccess = Math.abs(ballX - 400) < 50 && force > 30;
    let reward = goalSuccess ? 10 : 2;
    if (goalSuccess && (curve > 70 || force > 80)) reward += 5;
    coins += reward;
    ctx.fillStyle = goalSuccess ? "#0f0" : "#f00";
    ctx.fillText(goalSuccess ? "GOOOOL!" : "Errou!", 360, 300);
    ctx.fillStyle = "#0f0";
    ctx.fillText("Moedas: " + coins, 340, 340);
    setTimeout(() => {
      stage++;
      currentBar = 0;
      gameState = "velocity";
    }, 1500);
  }
}
